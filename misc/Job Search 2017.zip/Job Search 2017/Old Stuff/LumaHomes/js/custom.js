$(document).ready(function(e) {
    $('.cta-form-luma input[type=text], .cta-form-luma input[type=email]').click(function() {
		$(this).val('');	
	});
});