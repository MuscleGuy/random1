<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Simple EComemrce Developer Code Test</title>


<!--CSS STYLING-->
<link rel="stylesheet" href="css/base.css"/>
<link rel="stylesheet" href="css/normalize.css">
<link rel="stylesheet" href="css/skeleton.css">
<link rel="stylesheet" type="text/css" href="css/fullwidth.css" media="screen" />
<link rel="stylesheet" href="css/less-css.css"/>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
<link rel='shortcut icon' href='images/favicon.png' type='image/x-icon'/ > 

<!--JS SCRIPTS-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> 
<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/less.js/2.7.1/less.min.js"></script>
<script src="js/custom.js"></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'ENTER-YOUR-ID', 'auto');
  ga('send', 'pageview');

/*

(function() {
  var form = document.querySelector('#cta-form-luma');
  var fields = {};
  
  var enterField = function(name) {
    fields[name] = new Date().getTime();
  }
  
  var leaveField = function(e) {
    var timeSpent;
    var fieldName = e.target.name;
    var leaveType = e.type;
    if (fields.hasOwnProperty(fieldName)) {
      timeSpent = new Date().getTime() - fields[fieldName];
      if (timeSpent > 0 && timeSpent < 1800000) {
        window.dataLayer.push({
          'event' : 'fieldTiming',
          'timingCategory' : 'Comment Form Field Timing',
          'timingVariable' : fieldName,
          'timingLabel' : leaveType,
          'timingValue' : timeSpent
        });
      }
      delete fields[fieldName];
    }
  }
  
  if (form) {
    form.addEventListener('focus', function(e) { enterField(e.target.name); }, true);
    form.addEventListener('blur', function(e) { leaveField(e); }, true);
    form.addEventListener('change', function(e) { leaveField(e); }, true);
  }
})();

*/
</script>


</head>

<body>

<header>

<div class="container">

<div class="three columns">
  <img src="images/logo.png" width="129" height="53" title="Luma Surround Sound WiFi"> </div>

<div class="nine columns">

<nav class="main-nav u-pull-right">
<li><a href="https://getluma.com/surround-wifi/">Surround WiFi</a></li>
<li><a href="https://getluma.com/features/">Features</a></li>
<li><a href="http://support.getluma.com/">Support</a></li>
<li class="orange" ><a href="https://shop.getluma.com/products/luma-three-pack">Buy Now</a></li>
</nav>
</div>
</header>


<main id="main-body">

<div class="container">

<div class="six columns">

<p class="tagline">Fill Ever Room With Fast WiFi from luma<span class="mc_orange">.</span></p>
<form id="cta-form-luma" class="cta-form-luma">

<fieldset>

<table class="optin-table">
<tr><td><input type="text" name="fname" value="Full Name" placeholder="Full Name"/></td>
<td><input type="email" name="fname" value="Email" placeholder="Email"/></td></tr>
</table>
</fieldset>

<fieldset>
<table class="optin-table">
<tr><td><input type="text" name="fname" value="Number of Children" placeholder="Number of Children" onBlur="ga('send', 'event', { eventCategory: 'form', eventAction: 'submit', eventLabel: 'CTA', eventValue:NumberofChildren});"/></td>
<td><input type="text" name="fname" value="Average Age of Children" placeholder="Average Age of Children" onBlur="ga('send', 'event', { eventCategory: 'form', eventAction: 'submit', eventLabel: 'CTA', eventValue:AverageAgeofChildren});"/>
</td></tr>
</table>
</fieldset>

<fieldset>
<input type="submit" value="Sign Up For Special Offers!" />
</fieldset>
</form>

</div>

<div class="six columns phones"><img src="images/iphones.png" width="326" height="450" title="Luma Technology on Mobile Phones"></div>

</div>

</main>

<footer id="footer">

</footer>
</body>
</html>